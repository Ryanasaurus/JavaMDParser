package node;

public class InlineCodeNode {

}
